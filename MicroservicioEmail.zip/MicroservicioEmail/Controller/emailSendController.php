<?php
    class EmailController
    {
        public function send($to, $subject, $body)
        {
            $email = new Email();
            $email->send($to, $subject, $body);

            return [
                'success' => true,
                'message' => 'El correo electrónico se ha enviado correctamente',
            ];
        }
    }