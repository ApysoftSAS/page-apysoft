 // Obtén el elemento del enlace
 const enlaceTerminos = document.getElementById('enlaceTerminos');

 // Agrega un evento click al enlace para realizar la redirección
 enlaceTerminos.addEventListener('click', function (e) {
     // Evita que el enlace siga su comportamiento predeterminado (navegar a la página enlazada)
     e.preventDefault();
     
     // Obtiene la URL del enlace
     const urlTerminos = enlaceTerminos.getAttribute('View/Prueba.html');
     
     // Redirecciona a la página de términos y condiciones
     window.location.href = urlTerminos;
 });