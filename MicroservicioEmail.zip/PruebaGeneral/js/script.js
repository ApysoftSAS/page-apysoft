document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('register-form');
    const mensaje = document.getElementById('mensaje');

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const nombres = document.getElementById('nombres').value;
        const apellidos = document.getElementById('apellidos').value;
        const correo = document.getElementById('correo').value;
        const password = document.getElementById('password').value;
                // Envía los datos al servidor mediante AJAX
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'includes/guardar.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function () {
                    if (xhr.status === 200) {
                            mensaje.textContent = 'Registro exitoso';
                            loginForm.reset();
                    }
                    else {
                        mensaje.textContent = 'Hubo un error al registrar';
                    }
                };
                const data = `nombres=${nombres}&apellidos=${apellidos}&correo=${correo}&password=${password}`;
                xhr.send(data);
    });
});