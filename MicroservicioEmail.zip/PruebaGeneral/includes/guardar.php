<?php
include ('config.php');
// Recibe los datos del formulario
$nombres = $_POST['nombres'];
$apellidos = $_POST['password'];
$correo = $_POST['correo'];
$password = $_POST['password'];
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$sql = "INSERT INTO usuarios (nombres, apellidos, correo , password) VALUES ('$nombres', '$apellidos','$correo','$hashedPassword')";
if ($conexion->query($sql) === TRUE) {
    echo 'Registro exitoso';
} else {
    echo 'Error al registrar: ' . $conexion->error;
}
$conexion->close();
?>